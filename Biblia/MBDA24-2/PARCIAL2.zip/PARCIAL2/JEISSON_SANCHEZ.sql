

--MODELO RELACIONAL. INTEGRIDAD DECLARATIVA. (SQL Est�ndar)

--1. El tipo TTipoReporte es un valor entre [ventas, conciliaciones, disputas]
-- Como en SQL no se admiten dominios, se creo de esta manera...

/*
CREATE DOMAIN TTipoReporte AS VARCHAR(20) CONSTRAINT CHECK(
VALUE IN('ventas','conciliaciones','disputas')
);
*/


--2. La fecha de expiraci�n en evaluaciones debe ser mayor a la �ltima fecha

ALTER TABLE EVALUACIONES
ADD CONSTRAINT ck_fecha
CHECK (FECHA_EXPIRACION > ULTIMA_FECHA);


--3. No pueden existir m�s de 50 evaluaciones por herramientas con puntuaci�n menor a 3.0

-- Lo manejo asi ya que SQL no permite Assertion

/* CREATE ASSERTION ck_evaluaciones
CHECK(
    (SELECT COUNT(*)
     FROM EVALUACIONES
     WHERE PUNTUACION < 3) <= 50); */



--4. La herencia de usuarios debe ser exclusiva








-- MODELO RELACIONAL. INTEGRIDAD PROCEDIMENTAL. (SQL Est�ndar)

-- Registrar Evaluaciones

--  Adicionar

/*
Al adicionar una evaluaci�n solo se necesitar� el id del vendedor y el de la herramienta, 
dejando la puntuaci�n porefecto 3.0, �ltima fecha la actual, sin comentarios y con fecha de 
expiraci�n de un mes a partir de la fecha actual

Solucion:
Se debe crear un trigger antes de insertar en la tabla EVALUACIONES el cual asigne una puntuacion
de 3.0 por defecto, no agregue comentarios en la tabla EVALUACIONESCOMENTARIOS, y asigne fecha de 
expiracion como la fecha actual + 30 dias
*/

/*
Si la evaluaci�n tiene una puntuaci�n menor a 3.0, debe tener comentarios.

Solucion:
Se debe crear un trigger el cual antes de insertar en la tabla EVALUACIONES debe validar que si la 
puntuacion es menor a 3.0 debe insertar a su vez un comentario en la tabla EVALUACIONESCOMENTARIOS el 
cual debe llevar el IDEVALUACION y el comentario
*/


/*
No se pueden adicionar evaluaciones si la descripci�n de la herramienta es �deprecada�.

Solucion:
Se debe crear un trigger el cual antes de insertar en la tabla EVALUACIONES valide que en la tabla 
HERRAMIENTAS el IDHERRAMIENTA a insertar no tenga como descripcion "Deprecada", debe dar un 
error("La herramienta es deprecada, no se permite su evaluacion") 
*/

-- Modificar

/*
No se pueden modificar evaluaciones cuya fecha de expiraci�n ya haya pasado

Solucion:

Se debe crear un trigger el cual  antes de modificar la tabla EVALUACIONES valide que la fecha de 
expiracion sea menor a la fecha actual, si esto es valido debemos dar un error ("No se puede modificar,
la fecha de expiracion ya ha pasado")


*/

/* Solo se pueden modificar los comentarios de las evaluaciones 

Solucion:

Se crea un trigger el cual no deje modiicar los campos (ID_EVALUACION, PUNTUACION, ULTIMA_FECHA,
FECHA_EXPIRACION) usando el comando UPDATING, solo se podria modificar los cokmentarios en la tabla 
EVALUACIONESCOMENTARIOS

*/


-- Eliminar

/*
Al eliminar las herramientas, todas sus evaluaciones deber�n ser eliminadas

Solucion:

Se debe crear una accion la cual al hacer DELETE de una herramienta en la tabla HERRAMIENTA
se eliminen todos los registros relacionados con su Id en la tabla EVALUACIONES

*/

/*
Las evaluaciones se pueden eliminar si su puntuaci�n es mayor o igual a 3.0 y si no tienen comentarios

Solucion:

Se debe crear un trigger antes de eliminar un registro de la tabla EVALUACIONES el cual valide que la
puntuacion sea mayor o igual a 3.0 y que en la tabla EVALUACIONESCOMENTARIOS no hayan registros con el 
ID de esa evaluacion
*/





-- CONSTRUCCI�N (SQL ORACLE)
/*
Implemente la estructura de las tablas dise�adas en el diagrama conceptual. (Sin restricciones 
de integridad externa).
*/
CREATE TABLE REPORTES(
    ID_REPORTE VARCHAR(15) NOT NULL,
    NOMBRE VARCHAR(20) NOT NULL,
    TIPO VARCHAR(15) NOT NULL,
    FRECUENCIA VARCHAR(10)NOT NULL
);

CREATE TABLE EVALUACIONES(
    ID_EVALUACION VARCHAR(15) NOT NULL,
    PUNTUACION INT NOT NULL,
    ULTIMA_FECHA VARCHAR(11) NULL,
    FECHA_EXPIRACION VARCHAR(11) NOT NULL
    );

CREATE TABLE NOTIFICACIONES(
    ID_NOTIFICACION VARCHAR(15) NOT NULL,
    NOMBRE_REPORTE VARCHAR(20) NOT NULL,
    REGISTROS INT NOT NULL,
    TAMA�O VARCHAR(10) NOT NULL,
    ID_VENDEDOR INT NULL
    );
    

CREATE TABLE VENDEDORES(
    ID_VENDEDOR INT NOT NULL,
    TIPO VARCHAR(10) NOT NULL,
    PAIS_ORIGEN VARCHAR(20) NOT NULL
    );
    
CREATE TABLE USUARIOS(
    ID_USUARIO INT NOT NULL,
    NOMBRE VARCHAR(20) NOT NULL,
    EMAIL VARCHAR(50) NOT NULL
    );
    
CREATE TABLE COMPRADORES(
    ID_COMPRADOR INT NOT NULL,
    METO_PAGO VARCHAR(10) NOT NULL
    );

CREATE TABLE CUENTAS(
    NUMERO_CUENTA_BANCARIA INT NOT NULL,
    PAIS_PROCESAMIENTO VARCHAR(20) NOT NULL,
    BANCO VARCHAR(20) NOT NULL,
    ESTADO VARCHAR(1) NOT NULL,
    ID_VENDEDOR INT NOT NULL
    );

CREATE TABLE HERRAMIENTAS(
    ID_HERRAMIENTA INT NOT NULL,
    NOMBRE VARCHAR(20) NOT NULL,
    DESCRIPCION VARCHAR(100) NULL,
    VERSION VARCHAR(10) NOT NULL
    );

CREATE TABLE VENDEDORHERRAMIENTA(
    ID_HERRAMIENTA INT NOT NULL,
    ID_VENDEDOR INT NOT NULL
    );

CREATE TABLE REPORTESCAMPOS(
    ID_REPORTE VARCHAR(15) NOT NULL,
    CAMPO VARCHAR(20) NOT NULL
    );
    
CREATE TABLE EVALUACIONESCOMENTARIOS(
    ID_EVALUACION VARCHAR(15) NOT NULL,
    COMENTARIO VARCHAR(20) NOT NULL
    );
    
-- Llaves Primarias

ALTER TABLE REPORTES
ADD CONSTRAINT pk_reportes PRIMARY KEY (ID_REPORTE);

ALTER TABLE EVALUACIONES
ADD CONSTRAINT pk_evaluaciones PRIMARY KEY (ID_EVALUACION);
    
ALTER TABLE NOTIFICACIONES
ADD CONSTRAINT pk_notificaciones PRIMARY KEY (ID_NOTIFICACION);
        
ALTER TABLE VENDEDORES
ADD CONSTRAINT pk_vendedor PRIMARY KEY (ID_VENDEDOR);
    
ALTER TABLE USUARIOS
ADD CONSTRAINT pk_usuarios PRIMARY KEY (ID_USUARIO);

ALTER TABLE COMPRADORES
ADD CONSTRAINT pk_compradores PRIMARY KEY (ID_COMPRADOR);
    
ALTER TABLE CUENTAS
ADD CONSTRAINT pk_cuentas PRIMARY KEY (NUMERO_CUENTA_BANCARIA);
        
ALTER TABLE HERRAMIENTAS
ADD CONSTRAINT pk_herramientas PRIMARY KEY (ID_HERRAMIENTA);
                
ALTER TABLE VENDEDORHERRAMIENTA
ADD CONSTRAINT pk_vendedorherramienta PRIMARY KEY (ID_HERRAMIENTA,ID_VENDEDOR);
    
ALTER TABLE REPORTESCAMPOS
ADD CONSTRAINT pk_reportescampos PRIMARY KEY (ID_REPORTE,CAMPO);
    
ALTER TABLE EVALUACIONESCOMENTARIOS
ADD CONSTRAINT pk_evaluacionescomentarios PRIMARY KEY (ID_EVALUACION, COMENTARIO);

-- LLaves Foraneas

ALTER TABLE NOTIFICACIONES
ADD CONSTRAINT fk_notificaciones_1 FOREIGN KEY (ID_VENDEDOR) REFERENCES VENDEDORES(ID_VENDEDOR);

ALTER TABLE NOTIFICACIONES
ADD CONSTRAINT fk_notificaciones_2 FOREIGN KEY (ID_NOTIFICACION) REFERENCES REPORTES(ID_REPORTE);

ALTER TABLE VENDEDORES
ADD CONSTRAINT fk_vendedores FOREIGN KEY (ID_VENDEDOR) REFERENCES USUARIOS(ID_USUARIO);

ALTER TABLE COMPRADORES
ADD CONSTRAINT fk_compradores FOREIGN KEY (ID_COMPRADOR) REFERENCES USUARIOS(ID_USUARIO);

ALTER TABLE CUENTAS
ADD CONSTRAINT fk_cuentas FOREIGN KEY (ID_VENDEDOR) REFERENCES VENDEDORES(ID_VENDEDOR);

ALTER TABLE VENDEDORHERRAMIENTA
ADD CONSTRAINT fk_vendedor_h FOREIGN KEY (ID_VENDEDOR) REFERENCES VENDEDORES(ID_VENDEDOR);

ALTER TABLE VENDEDORHERRAMIENTA
ADD CONSTRAINT fk_vendedor_h2 FOREIGN KEY (ID_HERRAMIENTA) REFERENCES HERRAMIENTAS(ID_HERRAMIENTA);

ALTER TABLE REPORTESCAMPOS
ADD CONSTRAINT fk_reportes_c FOREIGN KEY (ID_REPORTE) REFERENCES REPORTES(ID_REPORTE);

ALTER TABLE EVALUACIONESCOMENTARIOS
ADD CONSTRAINT fk_EVALUACIONES_C FOREIGN KEY (ID_EVALUACION) REFERENCES EVALUACIONES(ID_EVALUACION);
