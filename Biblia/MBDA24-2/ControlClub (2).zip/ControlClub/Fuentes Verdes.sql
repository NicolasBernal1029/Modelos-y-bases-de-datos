/*
PROYECTO
Realizado por 
- Felipe Calvache
- Jeisson Sanchez
*/


-- xForaneas

ALTER TABLE PRODUCTO DROP CONSTRAINT fk_producto;
ALTER TABLE VENTA_PRODUCTO DROP CONSTRAINT fk_ventaProducto1;
ALTER TABLE VENTA_PRODUCTO DROP CONSTRAINT fk_ventaProducto2;
ALTER TABLE VENTA_EMPLEADO DROP CONSTRAINT fk_ventaEmpleado1;
ALTER TABLE VENTA_EMPLEADO DROP CONSTRAINT fk_ventaEmpleado2;
ALTER TABLE EVENTO DROP CONSTRAINT fk_evento;
ALTER TABLE RESERVA DROP CONSTRAINT fk_reserva1;
ALTER TABLE RESERVA DROP CONSTRAINT fk_reserva2;
ALTER TABLE DESCUENTO DROP CONSTRAINT fk_descuento;
ALTER TABLE FACTURA DROP CONSTRAINT fk_factura;
ALTER TABLE ELECTRONICA DROP CONSTRAINT fk_electronica;
ALTER TABLE FISICA DROP CONSTRAINT fk_fisica;
ALTER TABLE VALORACION DROP CONSTRAINT fk_valoracion;
ALTER TABLE MESA DROP CONSTRAINT fk_mesa;
ALTER TABLE PUBLICIDAD DROP CONSTRAINT fk_publicidad;
ALTER TABLE EVENTO DROP CONSTRAINT fk_evento2;
ALTER TABLE PRODUCTO DROP CONSTRAINT fk_producto2;
ALTER TABLE EMPLEADO_EVENTO DROP CONSTRAINT fk_empleadoEvento1;
ALTER TABLE EMPLEADO_EVENTO DROP CONSTRAINT fk_empleadoEvento2;


-- Tuplas 

ALTER TABLE PUBLICIDAD ADD CONSTRAINT ck_fecha1 CHECK (fechaInicio < fechaFin);
ALTER TABLE DESCUENTO ADD CONSTRAINT ck_fecha2 CHECK (fechaInicio < fechaFinal);


-- Acciones

ALTER TABLE PRODUCTO 
ADD CONSTRAINT fk_producto FOREIGN KEY (idProveedor) REFERENCES PROVEEDOR(id) ON DELETE CASCADE;

ALTER TABLE RESERVA 
ADD CONSTRAINT fk_reserva FOREIGN KEY (idEmpleado) REFERENCES EMPLEADO(id) ON DELETE CASCADE;

ALTER TABLE ELECTRONICA
ADD CONSTRAINT fk_electronica FOREIGN KEY (idFactura) REFERENCES FACTURA(id) ON DELETE CASCADE;

ALTER TABLE FISICA
ADD CONSTRAINT fk_fisica FOREIGN KEY (idFactura) REFERENCES FACTURA(id) ON DELETE CASCADE;

ALTER TABLE PAGO
ADD CONSTRAINT fk_pago FOREIGN KEY (idFactura) REFERENCES FACTURA(id) ON DELETE CASCADE;

ALTER TABLE MESA
ADD CONSTRAINT fk_mesa FOREIGN KEY (idReserva) REFERENCES RESERVA(id) ON DELETE CASCADE;

ALTER TABLE DESCUENTO
ADD CONSTRAINT fk_descuento FOREIGN KEY (idVenta) REFERENCES VENTA(id) ON DELETE CASCADE;


-- Disparadores

CREATE OR REPLACE TRIGGER TR_PRODUCTO_BI
BEFORE INSERT ON PRODUCTO
FOR EACH ROW
DECLARE
    max_id INT;
BEGIN
    
    SELECT NVL(MAX(TO_NUMBER(id)), 0) + 1 INTO max_id FROM PRODUCTO;
    :NEW.id := LPAD(TO_CHAR(max_id), 5, '0');
END;


CREATE OR REPLACE TRIGGER TR_EMPLEADO_BI
BEFORE INSERT ON EMPLEADO
FOR EACH ROW 
DECLARE
    max_id INT;
BEGIN
     SELECT NVL(MAX(TO_NUMBER(id)), 0) + 1 INTO max_id FROM empleado;
    :NEW.id := LPAD(TO_CHAR(max_id), 2, '0');
END;


CREATE OR REPLACE TRIGGER TR_VENTA_BI
BEFORE INSERT ON VENTA
FOR EACH ROW 
DECLARE
    max_id INT;
BEGIN
     SELECT NVL(MAX(TO_NUMBER(id)), 0) + 1 INTO max_id FROM venta;
    :NEW.id := LPAD(TO_CHAR(max_id), 6, '0');
    :NEW.fecha := SYSDATE;
END;


CREATE OR REPLACE TRIGGER TR_FACTURA_BI
BEFORE INSERT ON FACTURA
FOR EACH ROW
DECLARE
    max_id INT;
BEGIN
     SELECT NVL(MAX(TO_NUMBER(id)), 0) + 1 INTO max_id FROM factura;
    :NEW.id := LPAD(TO_CHAR(max_id), 11, '0');
    :NEW.fecha := SYSDATE;
END;


CREATE OR REPLACE TRIGGER TR_FACTURA_BD
BEFORE DELETE ON FACTURA
FOR EACH ROW
BEGIN
    -- Genera un error si se intenta eliminar una factura
    RAISE_APPLICATION_ERROR(-20001, 'No se permite la eliminaci�n de facturas.');
END;


CREATE OR REPLACE TRIGGER TR_EMPLEADO_BU
BEFORE UPDATE ON EMPLEADO
FOR EACH ROW
BEGIN
    -- Verificar si se intenta actualizar alg�n campo que no sea `cargo o telefono`
    IF :OLD.id != :NEW.id
       OR :OLD.nombre != :NEW.nombre
       OR :OLD.correo != :NEW.correo
       OR :OLD.ciudad != :NEW.ciudad THEN
       
        -- Lanza un error si se intenta modificar campos distintos de `cargo y telefono`
        RAISE_APPLICATION_ERROR(-20002, 'Solo se permite modificar el campo cargo y telefono.');
    END IF;
END;


CREATE OR REPLACE TRIGGER TR_FACTURA_BU
BEFORE UPDATE ON FACTURA
FOR EACH ROW
BEGIN
    -- Verificar si se intenta actualizar alg�n campo que no sea `montoTotal`
    IF :OLD.id != :NEW.id
       OR :OLD.cedula != :NEW.cedula
       OR :OLD.fecha != :NEW.fecha
       OR :OLD.idVenta != :NEW.idVenta THEN
       
        -- Lanza un error si se intenta modificar campos distintos de `montoTotal`
        RAISE_APPLICATION_ERROR(-20002, 'Solo se permite modificar el campo montoTotal.');
    END IF;
END;


CREATE OR REPLACE TRIGGER TR_ELECTRONICA_BU
BEFORE UPDATE ON ELECTRONICA
FOR EACH ROW
BEGIN
    -- Verificar si se intenta actualizar alg�n campo que no sea `montoTotal`
    IF :OLD.idFactura != :NEW.idFactura
       OR :OLD.nombreEmpresa != :NEW.nombreEmpresa
     THEN
       
        -- Lanza un error si se intenta modificar campos distintos de `montoTotal`
        RAISE_APPLICATION_ERROR(-20002, 'Solo se permite modificar el campo correo.');
    END IF;
END;


CREATE OR REPLACE TRIGGER TR_FISICA_BU
BEFORE UPDATE ON FISICA
FOR EACH ROW
BEGIN
    -- Verificar si se intenta actualizar alg�n campo que no sea `montoTotal`
    IF :OLD.idFactura != :NEW.idFactura
     
     THEN
       
        -- Lanza un error si se intenta modificar campos distintos de `montoTotal`
        RAISE_APPLICATION_ERROR(-20002, 'Solo se permite modificar el campo Telefono.');
    END IF;
END;


CREATE OR REPLACE TRIGGER TR_ELECTRONICA_BD
BEFORE DELETE ON ELECTRONICA
FOR EACH ROW
BEGIN
    -- Genera un error si se intenta eliminar una factura
    RAISE_APPLICATION_ERROR(-20001, 'No se permite la eliminaci�n de facturas electronicas.');
END;


CREATE OR REPLACE TRIGGER TR_FISICA_BD
BEFORE DELETE ON FISICA
FOR EACH ROW
BEGIN
    -- Genera un error si se intenta eliminar una factura
    RAISE_APPLICATION_ERROR(-20001, 'No se permite la eliminaci�n de facturas fisicas.');
END;


-- XDisparadores

DROP TRIGGER tr_producto_bi;
DROP TRIGGER TR_EMPLEADO_BI;
DROP TRIGGER TR_VENTA_BI;
DROP TRIGGER TR_FACTURA_BI;
DROP TRIGGER TR_FACTURA_BD;
DROP TRIGGER TR_EMPLEADO_BU;
DROP TRIGGER TR_FACTURA_BU;
DROP TRIGGER TR_ELECTRONICA_BU;
DROP TRIGGER TR_FISICA_BU;
DROP TRIGGER TR_ELECTRONICA_BD;
DROP TRIGGER TR_FISICA_BD;


-- TuplasOK

INSERT INTO PUBLICIDAD VALUES ('PUB080', 'Videos', 'Plataf. Dig.', TO_DATE('2026-03-15', 'YYYY-MM-DD'), TO_DATE('2026-03-30', 'YYYY-MM-DD'), 8000, '000000006');
INSERT INTO PUBLICIDAD VALUES ('PUB090', 'Videos', 'Plataf. Dig.', TO_DATE('2026-01-16', 'YYYY-MM-DD'), TO_DATE('2026-03-30', 'YYYY-MM-DD'), 8000, '000000006');

INSERT INTO DESCUENTO VALUES('999', '15\', 'descuento de aniversario', TO_DATE('2028-04-01', 'YYYY-MM-DD'), TO_DATE('2028-04-10', 'YYYY-MM-DD'), '000034');
INSERT INTO DESCUENTO VALUES('666', '15\', 'descuento de aniversario', TO_DATE('2028-01-01', 'YYYY-MM-DD'), TO_DATE('2028-04-10', 'YYYY-MM-DD'), '000034');


-- TuplasNoOK

INSERT INTO PUBLICIDAD VALUES ('PUB080', 'Videos', 'Plataf. Dig.', TO_DATE('2026-12-15', 'YYYY-MM-DD'), TO_DATE('2026-03-30', 'YYYY-MM-DD'), 8000, '000000006');
INSERT INTO PUBLICIDAD VALUES ('PUB080', 'Videos', 'Plataf. Dig.', TO_DATE('2026-12-20', 'YYYY-MM-DD'), TO_DATE('2026-01-30', 'YYYY-MM-DD'), 8000, '000000006');

INSERT INTO DESCUENTO VALUES('999', '15\', 'descuento de aniversario', TO_DATE('2028-04-01', 'YYYY-MM-DD'), TO_DATE('2028-01-10', 'YYYY-MM-DD'), '000034');
INSERT INTO DESCUENTO VALUES('999', '15\', 'descuento de aniversario', TO_DATE('2028-12-01', 'YYYY-MM-DD'), TO_DATE('2028-01-30', 'YYYY-MM-DD'), '000034');


-- AccionesOK

INSERT INTO FACTURA VALUES ('00000000060', '1001064920', TO_DATE('2024-01-01', 'YYYY-MM-DD'), 1000, '000001');
INSERT INTO PAGO VALUES ('P0000000060', 1000, 'TC', TO_DATE('2024-03-28', 'YYYY-MM-DD'), '00000000060');

SELECT *
FROM PAGO WHERE idFactura = '00000000060'

DELETE FROM FACTURA WHERE id = '00000000060';


INSERT INTO PROVEEDOR VALUES ('0000060', 'nombre 50', 'calle 50', '3233919891', 'alejandro@example.com', 'cerveza modelo');
INSERT INTO PRODUCTO VALUES ('00080', 'Producto 1', 1000, '0000060', '0001');

SELECT *
FROM PRODUCTO WHERE idProveedor = '0000060';

DELETE FROM PROVEEDOR WHERE id = '0000060';


INSERT INTO FACTURA VALUES ('00000000060', '1001064920', TO_DATE('2024-02-19', 'YYYY-MM-DD'), 25500, '000050');
INSERT INTO FISICA VALUES('3184118510', '00000000060');

SELECT *
FROM FISICA WHERE idFactura = '00000000060';

DELETE FROM FACTURA WHERE id = '00000000060';


-- DisparadoresOK

INSERT INTO PRODUCTO (descripcion, precio, idProveedor,idInventario) VALUES ('Producto 51', 55000,'0000050','0001' );

INSERT INTO EMPLEADO(nombre,cargo,telefono,correo,ciudad) VALUES ('Edna Navarro', 'M', '3501234578', 'ednan@example.com', 'Cali');

INSERT INTO VENTA (montoTotal) VALUES (50000);

INSERT INTO FACTURA(cedula,montoTotal,idVenta) VALUES ('123456789000051', 25500, '000050');

UPDATE EMPLEADO SET cargo = 'A', telefono = '3501234579' WHERE id = '01';

UPDATE FACTURA SET montoTotal = 2000 WHERE id = '00000000051';

UPDATE ELECTRONICA SET correo = 'contact@techcorp.com' WHERE idFactura = '00000000001';

UPDATE FISICA SET Telefono = '3007654321' WHERE idFactura = '00000000050';


-- DisparadoresNoOK

DELETE FROM FACTURA;

UPDATE EMPLEADO SET nombre = 'Edna P�rez' WHERE id = '001';

UPDATE FACTURA SET cedula = '987654321' WHERE id = '00000000051';

UPDATE ELECTRONICA SET nombreEmpresa = 'NewTechCorp' WHERE idFactura = '00000000001';

UPDATE FISICA SET idFactura = '00000000050' WHERE idFactura = '00000000051';

DELETE FROM ELECTRONICA;

DELETE FROM FISICA;

