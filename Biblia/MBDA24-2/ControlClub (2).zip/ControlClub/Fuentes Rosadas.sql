/*
PROYECTO
Realizado por 
- Felipe Calvache
- Jeisson Sanchez
*/



-- Indices

CREATE INDEX idx_fecha ON VENTA (fecha);


-- Vistas

CREATE VIEW ventaActual AS
SELECT SUM(montoTotal) AS total_ventas_dia
FROM VENTA
WHERE fecha = SYSDATE;


-- XIndicesVistas

DROP VIEW ventaActual;
DROP INDEX idx_fecha;


-- IndicesVistasOK

SELECT total_ventas_dia
FROM VentasDiaActual