/*
PROYECTO
Realizado por 
- Felipe Calvache
- Jeisson Sanchez
*/




-- Pruebas

/*
    Una tarde soleada, Jeisson, un apasionado cliente de la discoteca "ControlClub", decidi  hacer una reserva especial para celebrar su cumplea os. 
    Jeisson quer a asegurarse de que todo estuviera perfecto, as  que se dirigi  a la p gina web de la discoteca para realizar su reserva.
    Jeisson accedi  a la secci n de reservas y con una sonrisa en el rostro comenz  a completar la informaci n que le ped a la pagins.
    Utilizando la base de datos de la discoteca, Jw ejecut  el siguiente comando para registrar su reserva:
    
    INSERT INTO RESERVA VALUES('0059', TO_DATE('2028-02-13', 'YYYY-MM-DD'), 15, '12', '00000012');

    Con esta acci n, Jeisson registr  su reserva, asegur ndose de que la fecha, el n mero de personas y el ID de la reserva quedaran correctamente almacenados en la base de datos.
    Se le asign  un empleado a cargo de ellos toda la noche con el idEmpleado.
    
    Al mismo tiempo, Felipe, un empleado dedicado de la discoteca, recibi  una notificaci n sobre la nueva reserva de Jeisson. 
    Felipe, que siempre busca ofrecer el mejor servicio a sus clientes, decidi  revisar y confirmar la reserva de Jeisson.
    Felipe utiliz  el siguiente comando para listar todas las reservas y confirmar la informaci n:
    
    SELECT * FROM RESERVA;
    
    Al ver la reserva de Jeisson con su id de empleado asociado en la lista, Felipe se asegur  de que todos los detalles estuvieran correctos. 
    Luego, contact  a Jeisson para confirmar su reserva y discutir los detalles adicionales de la celebraci n.
    
    Jeisson, agradecido por la atenci n personalizada, agradeci  por la buena coordinaci n del sistema y la eficiencia.
    
    Gracias a la eficiente base de datos y al excelente trabajo en equipo, la fiesta de cumplea os de Jeisson fue un gran  xito. 
    Todos disfrutaron de una noche inolvidable, y Jeisson se sinti  especial y apreciado por la atenci n y el servicio que recibi .
    
    As , una vez m s, la base de datos de "ControlClub" demostr  ser una herramienta invaluable para ofrecer un servicio excepcional a sus clientes,
    y asegurar que cada celebraci n sea memorable.
    
    Le qued  gustando tanto la atenci n y la rapidez de organizaci n que decidi  volver a ControlClub
    Nuevamente, Jeisson siempre buscando lo mejor, decidi  hacer una reserva para una mesa VIP a trav s de la web de la discoteca.
    
    Una vez en la discoteca, Jeisson escogi  una elegante botella de champa a y decidi  proceder con la compra. 
    El encargado de la reserva, Felipe, le ayud  en el proceso utilizando el sistema de la discoteca, el cual estaba basado en paquetes de procedimientos almacenados 
    para gestionar las ventas eficientemente.
    
    Felipe utiliz  el siguiente comando para registrar la venta de manera r pida y segura mediante el paquete PA_VENTA:
    
    BEGIN 
        PA_VENTA.AD_venta( 150000); 
    END;
    
    select * from venta;
    
    como ControlClub solo utiliza tecnolog a nueva e innovadora porque vienen de la Escuela, Jeisson, curioso sobre c mo su compra era manejada por el sistema, 
    pregunt  a Felipe sobre el procedimiento. Felipe explic  que el comando anterior ejecutaba un procedimiento almacenado que no solo registraba la venta en la base de datos, 
    sino que tambi n aplicaba validaciones y actualizaba la factura, todo en un solo paso.
    
    Posteriormente, Felipe quiso revisar todas las ventas del d a para asegurarse de que todo estuviera en orden. 
    Utiliz  el siguiente comando para listar todas las ventas del d a que fueran mayores a 10.000 para premiar a los empleados que lograron vender la meta del d a.
    Usando la siguiente consulta:
    
    SELECT id, montoTotal
    FROM VENTA
    WHERE montoTotal > 10000
    
    Nuevamente Jeisson se sinti  bien atendido por el lugar y borracho empez  a agradecer a todos los trabajadores del lugar
    Pas  la mejor fiesta de su vida y agradeci  la eficiencia de la base de datos y el excelente trabajo de los empleados.
*/
