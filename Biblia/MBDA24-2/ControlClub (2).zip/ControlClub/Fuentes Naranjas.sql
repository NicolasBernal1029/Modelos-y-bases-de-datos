/*
PROYECTO
Realizado por 
- Felipe Calvache
- Jeisson Sanchez
*/


-- CRUDE

CREATE OR REPLACE PACKAGE PA_EMPLEADO AS 
    PROCEDURE AD_empleado(p_id IN VARCHAR, p_nombre IN VARCHAR, p_cargo IN CHAR, p_telefono IN VARCHAR, p_correo IN VARCHAR, p_ciudad IN VARCHAR); 
    PROCEDURE DE_empleado(p_id IN VARCHAR); 
    FUNCTION CO_empleado RETURN SYS_REFCURSOR; 
END PA_EMPLEADO;

CREATE OR REPLACE PACKAGE PA_PRODUCTO AS 
    PROCEDURE AD_producto(p_id IN VARCHAR, p_descripcion IN VARCHAR, p_precio IN INT, p_idProveedor IN VARCHAR, p_idInventario IN VARCHAR); 
    PROCEDURE DE_producto(p_id IN VARCHAR); 
    FUNCTION CO_producto RETURN SYS_REFCURSOR; 
END PA_PRODUCTO;

CREATE OR REPLACE PACKAGE PA_FACTURA AS 
    PROCEDURE AD_factura(p_id IN VARCHAR, p_cedula IN VARCHAR, p_fecha IN DATE, p_montoTotal IN INT, p_idVenta IN VARCHAR); 
    PROCEDURE DE_factura(p_id IN VARCHAR); 
    FUNCTION CO_factura RETURN SYS_REFCURSOR; 
END PA_FACTURA;

CREATE OR REPLACE PACKAGE PA_VENTA AS 
    PROCEDURE AD_venta(p_id IN VARCHAR, p_fecha IN DATE, p_montoTotal IN INT); 
    PROCEDURE DE_venta(p_id IN VARCHAR); 
    FUNCTION CO_venta RETURN SYS_REFCURSOR; 
END PA_VENTA;

CREATE OR REPLACE PACKAGE PA_FACTURA_ELECTRONICA AS 
    PROCEDURE AD_facturaElectronica(p_correo IN VARCHAR, p_nombreEmpresa IN VARCHAR, p_tipo IN CHAR, p_idFactura IN VARCHAR); 
    PROCEDURE DE_facturaElectronica(p_idFactura IN VARCHAR); 
    FUNCTION CO_facturaElectronica RETURN SYS_REFCURSOR; 
END PA_FACTURA_ELECTRONICA;

CREATE OR REPLACE PACKAGE PA_FACTURA_FISICA AS 
    PROCEDURE AD_facturaFisica(p_telefono IN VARCHAR, p_idFactura IN VARCHAR); 
    PROCEDURE DE_facturaFisica(p_idFactura IN VARCHAR); 
    FUNCTION CO_facturaFisica RETURN SYS_REFCURSOR; 
END PA_FACTURA_FISICA;


-- CRUDI

CREATE OR REPLACE PACKAGE BODY PA_EMPLEADO AS 
    PROCEDURE AD_empleado(p_id IN VARCHAR, p_nombre IN VARCHAR, p_cargo IN CHAR, p_telefono IN VARCHAR, p_correo IN VARCHAR, p_ciudad IN VARCHAR) IS 
    BEGIN 
        INSERT INTO EMPLEADO (id, nombre, cargo, telefono, correo, ciudad) 
        VALUES (p_id, p_nombre, p_cargo, p_telefono, p_correo, p_ciudad); 
    END AD_empleado; 
    
    PROCEDURE DE_empleado(p_id IN VARCHAR) IS 
    BEGIN 
        DELETE FROM EMPLEADO WHERE id = p_id; 
    END DE_empleado; 
    
    FUNCTION CO_empleado RETURN SYS_REFCURSOR IS 
        v_cursor SYS_REFCURSOR; 
    BEGIN 
        OPEN v_cursor FOR SELECT * FROM EMPLEADO; 
        RETURN v_cursor; 
    END CO_empleado; 
END PA_EMPLEADO;


CREATE OR REPLACE PACKAGE BODY PA_PRODUCTO AS
    PROCEDURE AD_producto(p_id IN VARCHAR, p_descripcion IN VARCHAR, p_precio IN INT, p_idProveedor IN VARCHAR, p_idInventario IN VARCHAR) IS
    BEGIN
        INSERT INTO PRODUCTO (id, descripcion, precio, idProveedor, idInventario)
        VALUES (p_id, p_descripcion, p_precio, p_idProveedor, p_idInventario);
    END AD_producto;
    
    PROCEDURE DE_producto(p_id IN VARCHAR) IS
    BEGIN
        DELETE FROM PRODUCTO WHERE id = p_id;
    END DE_producto;
    
    FUNCTION CO_producto RETURN SYS_REFCURSOR IS
        v_cursor SYS_REFCURSOR;
    BEGIN
        OPEN v_cursor FOR SELECT * FROM PRODUCTO;
        RETURN v_cursor;
    END CO_producto;
END PA_PRODUCTO;


CREATE OR REPLACE PACKAGE BODY PA_VENTA AS
    PROCEDURE AD_venta(p_id IN VARCHAR, p_fecha IN DATE, p_montoTotal IN INT) IS
    BEGIN
        INSERT INTO VENTA (id, fecha, montoTotal)  
        VALUES (p_id, p_fecha, p_montoTotal);
    END AD_venta;

    PROCEDURE DE_venta(p_id IN VARCHAR) IS
    BEGIN
        DELETE FROM VENTA WHERE id = p_id;
    END DE_venta;
    
    FUNCTION CO_venta RETURN SYS_REFCURSOR IS
        v_cursor SYS_REFCURSOR;
    BEGIN
        OPEN v_cursor FOR SELECT * FROM VENTA;
        RETURN v_cursor;
    END CO_venta;
END PA_VENTA;


CREATE OR REPLACE PACKAGE BODY PA_FACTURA AS 
    PROCEDURE AD_factura(p_id IN VARCHAR, p_cedula IN VARCHAR, p_fecha IN DATE, p_montoTotal IN INT, p_idVenta IN VARCHAR) IS 
    BEGIN 
        INSERT INTO FACTURA (id, cedula, fecha, montoTotal, idVenta) 
        VALUES (p_id, p_cedula, p_fecha, p_montoTotal, p_idVenta); 
    END AD_factura; 
    
    PROCEDURE DE_factura(p_id IN VARCHAR) IS 
    BEGIN 
        DELETE FROM FACTURA WHERE id = p_id; 
    END DE_factura; 
    
    FUNCTION CO_factura RETURN SYS_REFCURSOR IS 
        v_cursor SYS_REFCURSOR; 
    BEGIN 
        OPEN v_cursor FOR SELECT * FROM FACTURA; 
        RETURN v_cursor; 
    END CO_factura; 
END PA_FACTURA;


CREATE OR REPLACE PACKAGE BODY PA_FACTURA_ELECTRONICA AS 
    PROCEDURE AD_facturaElectronica(p_correo IN VARCHAR, p_nombreEmpresa IN VARCHAR, p_tipo IN CHAR, p_idFactura IN VARCHAR) IS 
    BEGIN 
        INSERT INTO ELECTRONICA (correo, nombreEmpresa, tipo, idFactura) 
        VALUES (p_correo, p_nombreEmpresa, p_tipo, p_idFactura); 
    END AD_facturaElectronica; 
    
    PROCEDURE DE_facturaElectronica(p_idFactura IN VARCHAR) IS 
    BEGIN 
        DELETE FROM ELECTRONICA WHERE idFactura = p_idFactura; 
    END DE_facturaElectronica; 
    
    FUNCTION CO_facturaElectronica RETURN SYS_REFCURSOR IS 
        v_cursor SYS_REFCURSOR; 
    BEGIN 
        OPEN v_cursor FOR SELECT * FROM ELECTRONICA; 
        RETURN v_cursor; 
    END CO_facturaElectronica; 
END PA_FACTURA_ELECTRONICA;


CREATE OR REPLACE PACKAGE BODY PA_FACTURA_FISICA AS 
    PROCEDURE AD_facturaFisica(p_telefono IN VARCHAR, p_idFactura IN VARCHAR) IS 
    BEGIN 
        INSERT INTO FISICA (telefono, idFactura) 
        VALUES (p_telefono, p_idFactura); 
    END AD_facturaFisica; 
    
    PROCEDURE DE_facturaFisica(p_idFactura IN VARCHAR) IS 
    BEGIN 
        DELETE FROM FISICA WHERE idFactura = p_idFactura; 
    END DE_facturaFisica; 
    
    FUNCTION CO_facturaFisica RETURN SYS_REFCURSOR IS 
        v_cursor SYS_REFCURSOR; 
    BEGIN 
        OPEN v_cursor FOR SELECT * FROM FISICA; 
        RETURN v_cursor; 
    END CO_facturaFisica; 
END PA_FACTURA_FISICA;


-- xCRUD


-- CRUDOK


-- CRUDNoOK








