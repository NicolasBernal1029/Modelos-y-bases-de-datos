/*
PROYECTO
Realizado por 
- Felipe Calvache
- Jeisson Sanchez
*/


-- ACTORESE


CREATE OR REPLACE PACKAGE PA_ADMINISTRADOR AS 
    PROCEDURE AD_EMPLEADO(Xnombre IN VARCHAR,Xcargo IN VARCHAR,Xtelefono IN VARCHAR,Xcorreo IN VARCHAR,Xciudad IN VARCHAR);
    PROCEDURE MOD_EMPLEADO(Xid IN VARCHAR,Xcargo IN VARCHAR,Xtelefono IN VARCHAR);
    PROCEDURE EL_EMPLEADO(Xid IN VARCHAR);
    FUNCTION CO_EMPLEADO RETURN SYS_REFCURSOR;
    
    PROCEDURE AD_EVENTO(Xid IN VARCHAR,Xnombre IN VARCHAR,Xfecha IN DATE, Xhora IN VARCHAR,Xdescripcion IN VARCHAR, XidReserva IN VARCHAR, XidDJ IN VARCHAR);
    PROCEDURE MOD_EVENTO(Xid IN VARCHAR,Xnombre IN VARCHAR,Xfecha IN DATE,Xdescripcion IN VARCHAR);
    FUNCTION CO_EVENTO RETURN SYS_REFCURSOR;
    
    
    PROCEDURE AD_MESA(Xid IN VARCHAR,Xcapacidad IN INT, Xubicacion IN VARCHAR,Xestado IN VARCHAR,XidReserva IN VARCHAR);
    PROCEDURE EL_MESA(Xid IN VARCHAR);
    FUNCTION CO_MESA RETURN SYS_REFCURSOR;
    
    PROCEDURE AD_PUBLICIDAD(Xid IN VARCHAR,Xtipo IN VARCHAR,Xcanal IN VARCHAR,XfechaInicio IN DATE,XfechaFin IN DATE,Xcosto IN INT, XidEvento IN VARCHAR);
    PROCEDURE MOD_PUBLICIDAD(Xid IN VARCHAR,XfechaInicio IN DATE,XfechaFin IN DATE);
    FUNCTION CO_PUBLICIDAD RETURN SYS_REFCURSOR;
    
 
     
END PA_ADMINISTRADOR;

CREATE OR REPLACE PACKAGE PA_CLIENTE AS 

    PROCEDURE AD_VALORACION(Xid IN VARCHAR,Xcalificacion IN INT,Xcomentario IN VARCHAR,Xfecha IN DATE,XidCliente IN VARCHAR); 
    FUNCTION CO_VALORACION RETURN SYS_REFCURSOR; 
END PA_CLIENTE;


-- ACTORESI

CREATE OR REPLACE PACKAGE BODY PA_ADMINISTRADOR IS
    PROCEDURE AD_EMPLEADO(Xnombre IN VARCHAR,Xcargo IN VARCHAR,Xtelefono IN VARCHAR,Xcorreo IN VARCHAR,Xciudad IN VARCHAR)
    IS 
    BEGIN
        INSERT INTO EMPLEADO(nombre,cargo,telefono,correo,ciudad)
        VALUES (Xnombre,Xcargo,Xtelefono,Xcorreo,Xciudad);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                raise_application_error(-20001,'Error al insertar empleado');
    END;
    
    PROCEDURE MOD_EMPLEADO(Xid IN VARCHAR,Xcargo IN VARCHAR,Xtelefono IN VARCHAR)
    IS
    BEGIN
    --BEGIN TRANSACTION
        UPDATE EMPLEADO 
        SET cargo = Xcargo, telefono = Xtelefono
        WHERE id = Xid;    
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN                
            ROLLBACK;
                raise_application_error(-20002,'Error al modificar empleado');
    END;
        
    PROCEDURE EL_EMPLEADO(Xid IN VARCHAR)
        IS
        BEGIN
            DELETE FROM EMPLEADO
            WHERE ID = Xid;
            COMMIT;
        EXCEPTION
            WHEN OTHERS THEN
                    ROLLBACK;
                    raise_application_error(-20003,'Error al eliminar EMPLEADO');
        END;  
    
    FUNCTION CO_EMPLEADO RETURN SYS_REFCURSOR IS 
        v_cursor SYS_REFCURSOR; 
    BEGIN 
        OPEN v_cursor FOR SELECT * FROM EMPLEADO; 
        RETURN v_cursor; 
    END; 
    
    PROCEDURE AD_EVENTO(Xid IN VARCHAR,Xnombre IN VARCHAR,Xfecha IN DATE, Xhora IN VARCHAR,Xdescripcion IN VARCHAR, XidReserva IN VARCHAR, XidDJ IN VARCHAR)
    IS 
    BEGIN
        --BEGIN TRANSACTION
        INSERT INTO EVENTO(id,nombre,fecha,hora,descripcion,idReserva,idDJ)
        VALUES (Xid,Xnombre,Xfecha,Xhora,Xdescripcion,XidReserva,XidDJ);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                raise_application_error(-20004,'Error al insertar evento');
    END;
    
    PROCEDURE MOD_EVENTO(Xid IN VARCHAR,Xnombre IN VARCHAR,Xfecha IN DATE,Xdescripcion IN VARCHAR)
    IS
    BEGIN
    --BEGIN TRANSACTION
        UPDATE EVENTO 
        SET nombre = Xnombre, fecha = Xfecha, descripcion = Xdescripcion
        WHERE id = Xid;    
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN                
            ROLLBACK;
                raise_application_error(-20005,'Error al modificar evento');
    END;
    
    FUNCTION CO_EVENTO RETURN SYS_REFCURSOR IS
        v_cursor SYS_REFCURSOR; 
    BEGIN 
        OPEN v_cursor FOR SELECT * FROM EVENTO; 
        RETURN v_cursor; 
    END; 
    
    PROCEDURE AD_MESA(Xid IN VARCHAR,Xcapacidad IN INT, Xubicacion IN VARCHAR,Xestado IN VARCHAR,XidReserva IN VARCHAR)
    IS 
    BEGIN
        --BEGIN TRANSACTION
        INSERT INTO MESA(id,capacidad,ubicacion,estado,idReserva)
        VALUES (Xid,Xcapacidad,Xubicacion,Xestado,XidReserva);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                raise_application_error(-2006,'Error al insertar MESA');
    END;
    
    
    PROCEDURE EL_MESA(Xid IN VARCHAR)
        IS
        BEGIN
            DELETE FROM MESA
            WHERE ID = Xid;
            COMMIT;
        EXCEPTION
            WHEN OTHERS THEN
                    ROLLBACK;
                    raise_application_error(-20007,'Error al eliminar MESA');
        END;  
        
    FUNCTION CO_MESA RETURN SYS_REFCURSOR IS
        v_cursor SYS_REFCURSOR; 
    BEGIN 
        OPEN v_cursor FOR SELECT * FROM MESA; 
        RETURN v_cursor; 
    END; 
    
    
    PROCEDURE AD_PUBLICIDAD(Xid IN VARCHAR,Xtipo IN VARCHAR,Xcanal IN VARCHAR,XfechaInicio IN DATE,XfechaFin IN DATE,Xcosto IN INT, XidEvento IN VARCHAR)
    IS 
    BEGIN
        --BEGIN TRANSACTION
        INSERT INTO PUBLICIDAD(id,tipo,canal,fechaInicio,fechaFin,costo,idEvento)
        VALUES (Xid,Xtipo,Xcanal,XfechaInicio,XfechaFin,Xcosto,XidEvento);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                raise_application_error(-2008,'Error al insertar PUBLICIDAD');
    END;
    
    PROCEDURE MOD_PUBLICIDAD(Xid IN VARCHAR,XfechaInicio IN DATE,XfechaFin IN DATE)
    IS
    BEGIN
    --BEGIN TRANSACTION
        UPDATE PUBLICIDAD 
        SET fechaInicio = XfechaInicio, fechaFin = XfechaFin
        WHERE id = Xid;    
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN                
            ROLLBACK;
                raise_application_error(-20009,'Error al modificar PUBLICIDAD');
    END;
        
    FUNCTION CO_PUBLICIDAD RETURN SYS_REFCURSOR IS
        v_cursor SYS_REFCURSOR; 
    BEGIN 
        OPEN v_cursor FOR SELECT * FROM PUBLICIDAD; 
        RETURN v_cursor; 
    END;
    
END PA_ADMINISTRADOR;

CREATE OR REPLACE PACKAGE BODY PA_CLIENTE IS 
    PROCEDURE AD_VALORACION(Xid IN VARCHAR,Xcalificacion IN INT,Xcomentario IN VARCHAR,Xfecha IN DATE,XidCliente IN VARCHAR)
    IS 
    BEGIN
        --BEGIN TRANSACTION
        INSERT INTO valoracion(id,calificacion,comentario,fecha,idCliente)
        VALUES (Xid,Xcalificacion,Xcomentario,Xfecha,XidCliente);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
                raise_application_error(-200010,'Error al insertar valoracion');
    END;
   
   
    FUNCTION CO_VALORACION RETURN SYS_REFCURSOR IS 
        v_cursor SYS_REFCURSOR; 
    BEGIN 
        OPEN v_cursor FOR SELECT * FROM VALORACION; 
        RETURN v_cursor; 
    END;
END PA_CLIENTE;

--ACTORES OK
       
BEGIN
    PA_ADMINISTRADOR.AD_EMPLEADO('Jeisson','C','3184115196','jeisson@g.com','Bogota');
END;

BEGIN
    PA_CLIENTE.AD_VALORACION('V0051', 5, 'Muy buen lugar, todo estuvo de maravilla', TO_DATE('2024-03-30', 'YYYY-MM-DD'), '00000050');
END;

DECLARE
    v_id VARCHAR(6) := 'PUB001'; 
    v_fechaInicio DATE := TO_DATE('2024-12-15', 'YYYY-MM-DD'); 
    v_fechaFin DATE := TO_DATE('2024-12-30', 'YYYY-MM-DD');  
BEGIN
    PA_ADMINISTRADOR.MOD_PUBLICIDAD(v_id, v_fechaInicio, v_fechaFin);
END;


-- Seguridad


-- xSeguridad


-- SeguridadOK