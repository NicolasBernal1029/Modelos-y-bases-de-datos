-- Eliminación de paquetes
DROP PACKAGE PK_EQUIPOS;
DROP PACKAGE PK_GERENTE;
--
-- Eliminación de roles
DROP ROLE EQUIPOS;
DROP ROLE GERENTE_DEPORTIVO;



