-- X tablas

DROP TABLE Hinchas;
DROP TABLE Estadios;
DROP TABLE TieneResultadosDe;
DROP TABLE Canteranos;
DROP TABLE Extranjeros;
DROP TABLE CorreosPorRepresentantes;
DROP TABLE Prestamos;
DROP TABLE Transferencias;
DROP TABLE Documentaciones;
DROP TABLE CorreosPorGerentes;
DROP TABLE Financieros;
DROP TABLE Deportivos;
DROP TABLE Gerentes;
DROP TABLE Representantes;
DROP TABLE Partidos;
DROP TABLE Contratos;
DROP TABLE Jugadores;
DROP TABLE Equipos;

COMMIT;