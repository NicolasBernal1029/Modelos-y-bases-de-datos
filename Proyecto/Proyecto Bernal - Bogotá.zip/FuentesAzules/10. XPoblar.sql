-- xPoblar

DELETE FROM Hinchas;
DELETE FROM Estadios;
DELETE FROM TieneResultadosDe;
DELETE FROM Canteranos;
DELETE FROM Extranjeros;
DELETE FROM CorreosPorRepresentantes;
DELETE FROM Prestamos;
DELETE FROM Transferencias;
DELETE FROM Documentaciones;
DELETE FROM CorreosPorGerentes;
DELETE FROM Financieros;
DELETE FROM Deportivos;
DELETE FROM Gerentes;
DELETE FROM Representantes;
DELETE FROM Partidos;
DELETE FROM Contratos;
DELETE FROM Jugadores;
DELETE FROM Equipos;

COMMIT;